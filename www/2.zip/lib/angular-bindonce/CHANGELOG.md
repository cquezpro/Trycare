# 0.3.3 (2014-02-12)
### Features
- **bo-disabled:**
  - Add support for ng-disabled/bo-disabled #110

<hr />
# 0.3.2 (2014-11-23)
### Bug Fixes
- **Angular 1.3 compatibility**

<hr />
# 0.3.1 (2014-02-12)
### Features
- **bo-bind:**
  - alias for bo-text

### Bug Fixes
- **Angular Promises**
	- Ensures that promises are resolved before to run binders ([b3ef1b4](https://github.com/Pasvaz/bindonce/commit/b3ef1b46edfe83f10ed455d5520027f731563f32))

### Minor improvements
- Updated Readme

<hr />
# 0.3.0 (2014-01-21)
### Features
- **bo-switch:**
  - Create new directive: bo-switch ([652d0db](https://github.com/Pasvaz/bindonce/commit/652d0db04325166a180377c738a376543b5f2357))

<hr />
# 0.2.3 (2014-01-20)
### Bug Fixes

- **bo-if:**
	- Ensures that we both process newly added binders from bo-if, and that
we only process each binder once ([d11f863](https://github.com/Pasvaz/bindonce/commit/e091c273bbd17603d410fecc363874f0d1e6f38e))

### Features

- **Minification:**
  - add min file ([47277ee](https://github.com/Pasvaz/bindonce/commit/47277eedd092b3210de362c725a7dadcddac8e87))
- **Changelog:**
  - Created a changelog file
